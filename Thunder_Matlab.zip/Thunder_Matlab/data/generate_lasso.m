clear all;
close all;

N =20;
P = 100;

sp_level = 0.2;

X = 2*(rand(N,P)-0.5)*10;

b_num = ceil(P*sp_level);

B = zeros(P,1);
b_rand = randperm(P);

for i = 1:b_num
   B(b_rand(i)) = 2*(rand(1,1)-0.5); 
end

noiset = mvnrnd(zeros(N,1),10*diag(ones(N,1)));
Y = X*B +  noiset;

%my = median(Y);
%Y(Y<my) = -1;
%Y(Y>=my) = 1;

%filenm = ['lasso_sim_P' num2str(P) '_N_' num2str(N) '.mat'];

filenm = 'simulation.mat';
save(filenm,'Y','X','B');






