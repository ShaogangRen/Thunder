This is a Matlab implementation of Thunder algorithm with one remaining set. 

To run the demo on a simulation dataset,
a. run data/generate_lasso.m to generate a dataset
b. run demo_thunder.m


You can modify the set up in  demo_thunder.m to run the code on other datasets. 


The code can only be used for research purpose.
Citation:
@article{ren2020thunder,
  title={Thunder: a Fast Coordinate Selection Solver for Sparse Learning},
  author={Ren, Shaogang and Zhao, Weijie and Li, Ping},
  journal={Advances in Neural Information Processing Systems (NeurIPS)},
  volume={33},
  year={2020}
}