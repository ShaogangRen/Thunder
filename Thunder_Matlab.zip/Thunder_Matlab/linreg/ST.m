function res = ST(u,x)
if x>u
    res = x-u;
elseif x<-u
    res= x+u;
else
    res = 0;
end
       
