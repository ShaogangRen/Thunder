function w = inner_solver_dense(X, y, w, alpha, max_epochs)
[N,P] = size(X);
R = y - X*w;
for t =1:max_epochs
    for j = 1:P
        xj = X(:, j);
        old_wj = w(j);
        wj =  w(j);
        xsq = (xj'*xj);
        wj = wj +  xj'*R/xsq;
        wj = ST(alpha/xsq, wj); %%%????
        w(j) = wj;
        tmp = wj - old_wj;
        if tmp ~= 0.0
            tmp = -tmp;
            R = xj*tmp + R;
        end
    end
end
