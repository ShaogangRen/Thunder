clear all;
close all;

addpath(genpath('linreg/'));


load('simulation.mat');

eY = Y;
eX = X;

size(eX)
size(eY)

OptTol = 0.001; %% duality gap stopping condition
lammax = max(abs(eX'*eY));

lambda = 0.06*lammax;  %% model hyperparameter
verbose = 0;

[beta, time_thunder, time_cpp, Act_Feat_thunder, Added_Feat_thunder, ite]= thunder(eX, eY, lambda, OptTol, verbose);


disp("=========thunder===========");
time_thunder 
Act_Feat_thunder
Added_Feat_thunder


